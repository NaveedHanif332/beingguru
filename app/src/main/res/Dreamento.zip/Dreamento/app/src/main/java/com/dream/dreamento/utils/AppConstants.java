package com.dream.dreamento.utils;
public class AppConstants {
    public static final String KEYWORD = "world";
    public static final String YOUTUBE = "AIzaSyATcpF10RHJ2ChC4pQnNBhNpRPxkBxyUzo";
    //public static final String YOUTUBE = "AIzaSyBhvMtYoSfKNOb4BLFTZYzEu8NqkMsTM-0";
    public static final String NEWS_ID = "id";
    public static String email = "Email";
    public static String isChecked="isChecked";
    public static final String KEY_HEADERCOLOR = "headerColor";
    public static final String KEY_FOOTERCOLOR = "footerColor";
    public static final String KEY_PRIMARYCOLOR = "primaryColor";
    public static final String KEY_LOGO = "logo";

}
