package com.dream.dreamento.Home;

public interface ItemClickListener<T> {
    void onItemClicked(int position, SubCategoriesModel model);
}